export const TEST_URL = "http://localhost:8080";
export const DEV_URL = "https://mhs-backend.azurewebsites.net";
export const API_KEY = "454e3ceaeff4ef53ffd79472";
