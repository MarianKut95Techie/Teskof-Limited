import React from "react";
import "../Donate.css";

export default function DonateForm() {
  return (
    <>
      <div class="field padding-bottom--24">
        <div>
          <label for="email">Amount</label>
          <input type="number" name="amount" min={0} />
        </div>
        <div>
          <label for="email">Amount</label>
          <input type="number" name="amount" min={0} />
        </div>
      </div>

      <div style={{ marginTop: "30px" }} class="field padding-bottom--24">
        <input type="submit" name="submit" value="Pay" />
      </div>
    </>
  );
}
