import React, { useState } from "react";
import gold from "../images/cause/1.jpg";
import silver from "../images/cause/2.jpg";
import bronze from "../images/cause/3.jpg";
import PackagePayment from "./PackagePayment";
import { Elements } from "@stripe/react-stripe-js";
import { stripePromise } from "./Payment";
import axios from "axios";
import { API_KEY } from "../constants";

export default function Package() {
  const [showPayment, setShowPayment] = useState(false);
  const [amount, setAmount] = useState(0);

  async function convertAmount(amount) {
    const res = await axios.get(
      `https://v6.exchangerate-api.com/v6/${API_KEY}/latest/GHS`
    );
    const rate = res.data.conversion_rates.GBP;
    setAmount(rate * amount);
  }
  return (
    <div className="container">
      <div className="row">
        <div className="col-md-9 col-sm-8 col-xs-12">
          <div className="section-title">
            <h2>
              All <span className="thm-color">Packages</span>
            </h2>
          </div>
        </div>
      </div>

      <div className="row">
        <article className="item col-md-4 col-sm-6 col-xs-12">
          <figure className="img-box">
            <img alt="" src={gold} />

            <div className="overlay">
              <div className="inner-box">
                <div className="content-box">
                  <button
                    onClick={() => {
                      setShowPayment(true);
                      convertAmount(48000);
                      //   setAmount(48000);
                    }}
                    className="thm-btn style-2 donate-box-btn"
                  >
                    purchase now
                  </button>
                </div>
              </div>
            </div>
          </figure>

          <div className="content">
            <div className="text center">
              <a href="#">
                <h4 className="title">Gold Package</h4>
              </a>

              <p>
                Offer 1st Month Free
                <br />
                Duration: 12 months
                <br />
                Staff training & Development
                <br />
                Database Management Services
                <br />
                Medical Supplies
                <br />
                Suppy of Health Workforce
              </p>
            </div>

            <div className="donate clearfix">
              <div className="donate float_left">
                <button
                  onClick={() => {
                    setShowPayment(true);
                    convertAmount(48000);
                    // setAmount(48000);
                  }}
                >
                  Purchase
                </button>
              </div>

              <div className="donate float_right">
                <span>Price: GHS 48,000</span>
              </div>
            </div>
          </div>
        </article>

        <article className="item col-md-4 col-sm-6 col-xs-12">
          <figure className="img-box">
            <img alt="" src={silver} />

            <div className="overlay">
              <div className="inner-box">
                <div className="content-box">
                  <button
                    onClick={() => {
                      setShowPayment(true);
                      convertAmount(24000);
                      //   setAmount(24000);
                    }}
                    className="thm-btn style-2 donate-box-btn"
                  >
                    purchase now
                  </button>
                </div>
              </div>
            </div>
          </figure>

          <div className="content">
            <div className="text center">
              <a href="#">
                <h4 className="title">Silver Package</h4>
              </a>

              <p>
                Offer 1st Month Free
                <br />
                Duration: 6 months
                <br />
                Database Management Services
                <br />
                Medical Supplies
                <br />
                Suppy of Health Workforce
                <br />
                <br />
              </p>
            </div>

            <div className="donate clearfix">
              <div className="donate float_left">
                <button
                  onClick={() => {
                    setShowPayment(true);
                    convertAmount(24000);
                    // setAmount(24000);
                  }}
                >
                  Purchase
                </button>
              </div>

              <div className="donate float_right">
                <span>Price: GHS 24,000</span>
              </div>
            </div>
          </div>
        </article>

        <article className="item col-md-4 col-sm-6 col-xs-12">
          <figure className="img-box">
            <img alt="" src={bronze} />

            <div className="overlay">
              <div className="inner-box">
                <div className="content-box">
                  <button
                    onClick={() => {
                      setShowPayment(true);
                      convertAmount(12000);
                      //   setAmount(12000);
                    }}
                    className="thm-btn style-2 donate-box-btn"
                  >
                    purchase now
                  </button>
                </div>
              </div>
            </div>
          </figure>

          <div className="content">
            <div className="text center">
              <a href="#">
                <h4 className="title">Bronze Package</h4>
              </a>

              <p>
                Offer 1st Month Free
                <br />
                Duration: 3 months
                <br />
                Database Management Services
                <br />
                Medical Supplies
                <br />
                <br />
                <br />
              </p>
            </div>

            <div className="donate clearfix">
              <div className="donate float_left">
                <button
                  onClick={() => {
                    setShowPayment(true);
                    convertAmount(12000);
                    // setAmount(12000);
                  }}
                >
                  Purchase
                </button>
              </div>

              <div className="donate float_right">
                <span>Price: GHS 12,000</span>
              </div>
            </div>
          </div>
        </article>
        {showPayment && (
          <Elements stripe={stripePromise}>
            <PackagePayment amount={amount} />
          </Elements>
        )}
      </div>
    </div>
  );
}
