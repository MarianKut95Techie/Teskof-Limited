const express = require("express");
const app = express();
require("dotenv").config();
const stripe = require("stripe")(process.env.STRIPE_SECRET_TEST);
const bodyParser = require("body-parser");
const cors = require("cors");
const nodemailer = require("nodemailer");
const fileupload = require("express-fileupload");

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use(fileupload());
app.use(express.static("files"));

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "sheriffolamilekabadmus@gmail.com",
    pass: "dbhudbqsxypbhbrh",
  },
});

app.post("/appointment/new", cors(), async (req, res) => {
  try {
    var mailOptions = {
      from: "sholeka2000@gmail.com",
      to: process.env.RECEPIENT_EMAIL,
      subject: `APOINTMENT FROM ${req.body.name}`,
      html: `<span>Name: <strong>${req.body.name}</strong></span><br/>
      <span>Date of birth: <strong>${req.body.dob}</strong></span><br/>
      <span>Email: <strong>${req.body.email}</strong></span><br/>
      <span>Phone Number: <strong>${req.body.phoneNumber}</strong></span><br/>
      <span>Gender: <strong>${req.body.gender}</strong></span><br/>
      <span>Occupation: <strong>${req.body.occupation}</strong></span><br/>
      <span>Title: <strong>${req.body.title}</strong></span><br/>
      <span>Height: <strong>${req.body.height}</strong></span><br/>
      <span>Weight: <strong>${req.body.weight}</strong></span><br/>      
      `,
    };

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        res.json({
          message: "Appointment booking failed, kindly try again",
          success: false,
        });
      } else {
        res.json({
          message: "Appointment booked successfully",
          success: true,
        });
      }
    });
  } catch (error) {
    // console.log(error);
    res.json({
      message: "APpoint request failed, kindly try again",
      success: false,
    });
  }
});

app.post("/volunteer/new", cors(), async (req, res) => {
  try {
    // console.log(req.files.ID);
    var mailOptions = {
      from: "sholeka2000@gmail.com",
      to: process.env.RECEPIENT_EMAIL,
      subject: `VOLUNTEER REQUEST FROM ${req.body.name}`,
      html: `<span>Name: <strong>${req.body.name}</strong></span><br/>
      <span>Nationality: <strong>${req.body.nationality}</strong></span><br/>
      <span>Email: <strong>${req.body.email}</strong></span><br/>
      <span>Phone Number: <strong>${req.body.phoneNumber}</strong></span><br/>
      <span>Address: <strong>${req.body.address}</strong></span><br/>
      `,
      attachments: [
        {
          filename: req.files.ID.name,
          content: Buffer.from(req.files.ID.data, "base64"),
        },
        {
          filename: req.files.CV.name,
          content: Buffer.from(req.files.CV.data, "base64"),
        },
      ],
    };

    transporter.sendMail(mailOptions, function (error, info) {
      if (error) {
        res.json({
          message: "Request failed, kindly try again",
          success: false,
        });
      } else {
        res.json({
          message: "Request sent successfully",
          success: true,
        });
      }
    });
  } catch (error) {
    // console.log(error);
    res.json({
      message: "Request failed, kindly try again",
      success: false,
    });
  }
});

app.post("/stripe/charge", cors(), async (req, res) => {
  let { amount, id } = req.body;
  try {
    var mailOptions = {
      from: "sholeka2000@gmail.com",
      to: process.env.RECEPIENT_EMAIL,
      subject: "DONATION",
      text: `A donation of ${amount} pound has been made`,
    };
    const payment = await stripe.paymentIntents.create({
      amount: amount,
      currency: "GBP",
      description: "Tesk Off Donations",
      payment_method: id,
      confirm: true,
    });
    transporter.sendMail(mailOptions);
    res.json({
      message: "Payment Successful",
      success: true,
    });
  } catch (error) {
    res.json({
      message: "Payment Failed",
      success: false,
    });
  }
});

app.get("/", (req, res) => {
  res.send("James Forson");
});

app.listen(process.env.PORT || 3000, () => {
  // console.log("Server started....");
});
